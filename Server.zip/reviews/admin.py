from django.contrib import admin
from .models import Areas, Reviews

# Register your models here.
admin.site.register(Areas)
admin.site.register(Reviews)