from django.contrib import admin
from area.models import Area

# Register your models here.
admin.site.register(Area)